if __name__ == "__main__":
    print("Welcome to this part of TurathLLM 🚀")
    # Connect pipeline steps here
