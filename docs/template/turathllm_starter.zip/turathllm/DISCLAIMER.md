# 📢 Disclaimer & Ethical Notice
TurathLLM includes content and data sourced from various public and scholarly domains.
...
May Allah reward everyone who contributed to preserving Islamic knowledge. Ameen.
