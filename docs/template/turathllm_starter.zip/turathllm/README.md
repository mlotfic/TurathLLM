# 📚 TurathLLM
**Bridging classical Islamic texts and modern AI.**
...
**Reviving classical knowledge, powered by modern tools.**
