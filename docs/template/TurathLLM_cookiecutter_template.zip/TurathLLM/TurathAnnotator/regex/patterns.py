# Regex patterns for text annotation
patterns = []
